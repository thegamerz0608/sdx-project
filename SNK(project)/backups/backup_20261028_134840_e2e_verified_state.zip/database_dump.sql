-- Faculty ERP Database Snapshot: backup_20261028_134840_e2e_verified_state
-- Generated At: 2026-10-28T13:48:40.601001 by admin
SET FOREIGN_KEY_CHECKS = 0;

-- Table: system_settings (4 rows)
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`) VALUES (1, 'INSTITUTION_NAME', 'College of Engineering & Technology', 'Full official institution name', '2026-10-28 13:48:40');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`) VALUES (2, 'OFFICIAL_LOGIN_TIME', '09:00:00', 'Morning login deadline', '2026-10-28 13:48:40');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`) VALUES (3, 'MONTHLY_GRACE_MINUTES', '45', 'Monthly grace allowance', '2026-10-28 13:48:40');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`) VALUES (4, 'SYSTEM_VERSION', '1.0.0', 'Current ERP release version', '2026-10-28 13:48:40');

-- Table: users (4 rows)
INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `status`, `created_at`) VALUES (1, 'admin', '31323334353637383930313233343536$18cb20a8f348be90166d435db17b182cd03c356fd8381afa395b98c8eee14b87', 'ADMIN', 'ACTIVE', '2026-10-28 13:48:40');
INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `status`, `created_at`) VALUES (2, 'hod_mca', '31323334353637383930313233343536$18cb20a8f348be90166d435db17b182cd03c356fd8381afa395b98c8eee14b87', 'HOD', 'ACTIVE', '2026-10-28 13:48:40');
INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `status`, `created_at`) VALUES (3, 'fac_rahul', '31323334353637383930313233343536$18cb20a8f348be90166d435db17b182cd03c356fd8381afa395b98c8eee14b87', 'FACULTY', 'ACTIVE', '2026-10-28 13:48:40');
INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `status`, `created_at`) VALUES (4, 'fac_priya', '31323334353637383930313233343536$18cb20a8f348be90166d435db17b182cd03c356fd8381afa395b98c8eee14b87', 'FACULTY', 'ACTIVE', '2026-10-28 13:48:40');

-- Table: departments (3 rows)
INSERT INTO `departments` (`id`, `code`, `name`, `hod_faculty_id`, `status`, `created_at`) VALUES (1, 'MCA', 'Department of Computer Applications', 1, 'ACTIVE', '2026-10-28 13:48:40');
INSERT INTO `departments` (`id`, `code`, `name`, `hod_faculty_id`, `status`, `created_at`) VALUES (2, 'CSE', 'Department of Computer Science & Engineering', NULL, 'ACTIVE', '2026-10-28 13:48:40');
INSERT INTO `departments` (`id`, `code`, `name`, `hod_faculty_id`, `status`, `created_at`) VALUES (3, 'IT', 'Department of Information Technology', NULL, 'ACTIVE', '2026-10-28 13:48:40');

-- Table: faculty (3 rows)
INSERT INTO `faculty` (`id`, `employee_code`, `user_id`, `department_id`, `first_name`, `last_name`, `email`, `designation`, `joining_date`, `status`) VALUES (1, 'F001', 2, 1, 'Dr. Suresh', 'Kumar', 'hod.mca@erp.edu', 'Professor & HOD', '2015-06-15', 'ACTIVE');
INSERT INTO `faculty` (`id`, `employee_code`, `user_id`, `department_id`, `first_name`, `last_name`, `email`, `designation`, `joining_date`, `status`) VALUES (2, 'F002', 3, 1, 'Rahul', 'Sharma', 'rahul.sharma@erp.edu', 'Assistant Professor', '2021-08-10', 'ACTIVE');
INSERT INTO `faculty` (`id`, `employee_code`, `user_id`, `department_id`, `first_name`, `last_name`, `email`, `designation`, `joining_date`, `status`) VALUES (3, 'F003', 4, 1, 'Priya', 'Verma', 'priya.verma@erp.edu', 'Associate Professor', '2019-03-01', 'ACTIVE');

-- Table: leave_types (4 rows)
INSERT INTO `leave_types` (`id`, `code`, `name`, `max_days_per_year`, `carry_forward_allowed`, `requires_document`, `ai_classification_enabled`, `is_active`) VALUES (1, 'CL', 'Casual Leave', 12, 0, 0, 1, 1);
INSERT INTO `leave_types` (`id`, `code`, `name`, `max_days_per_year`, `carry_forward_allowed`, `requires_document`, `ai_classification_enabled`, `is_active`) VALUES (2, 'ML', 'Medical Leave', 10, 1, 1, 1, 1);
INSERT INTO `leave_types` (`id`, `code`, `name`, `max_days_per_year`, `carry_forward_allowed`, `requires_document`, `ai_classification_enabled`, `is_active`) VALUES (3, 'EL', 'Earned Leave', 15, 1, 0, 1, 1);
INSERT INTO `leave_types` (`id`, `code`, `name`, `max_days_per_year`, `carry_forward_allowed`, `requires_document`, `ai_classification_enabled`, `is_active`) VALUES (4, 'OD', 'On Duty Leave', 15, 0, 1, 1, 1);

-- Table: leave_balance (3 rows)
INSERT INTO `leave_balance` (`id`, `faculty_id`, `leave_type_id`, `year`, `allocated_days`, `used_days`, `pending_days`, `remaining_days`) VALUES (1, 2, 1, 2026, 12.0, 2.0, 0.0, 10.0);
INSERT INTO `leave_balance` (`id`, `faculty_id`, `leave_type_id`, `year`, `allocated_days`, `used_days`, `pending_days`, `remaining_days`) VALUES (2, 2, 2, 2026, 10.0, 0.0, 0.0, 10.0);
INSERT INTO `leave_balance` (`id`, `faculty_id`, `leave_type_id`, `year`, `allocated_days`, `used_days`, `pending_days`, `remaining_days`) VALUES (3, 3, 1, 2026, 12.0, 1.0, 0.0, 11.0);

-- Table: leave_applications (1 rows)
INSERT INTO `leave_applications` (`id`, `application_code`, `faculty_id`, `requested_leave_type_id`, `from_date`, `to_date`, `total_days`, `reason`, `ai_predicted_type_id`, `ai_confidence`, `status`, `reviewed_by_user_id`, `created_at`) VALUES (101, 'LV-2026-101', 2, 1, '2026-10-28', '2026-10-28', 1.0, 'Family emergency and urgent personal work', 1, 0.94, 'APPROVED', 2, '2026-10-28 13:48:40');

-- Table: attendance (2 rows)
INSERT INTO `attendance` (`id`, `faculty_id`, `attendance_date`, `login_time`, `logout_time`, `status`, `late_minutes`, `working_hours`, `created_at`) VALUES (1, 2, '2026-10-28', '09:05:00', '17:00:00', 'PRESENT', 5, 7.92, '2026-10-28 13:48:40');
INSERT INTO `attendance` (`id`, `faculty_id`, `attendance_date`, `login_time`, `logout_time`, `status`, `late_minutes`, `working_hours`, `created_at`) VALUES (2, 3, '2026-10-28', '08:55:00', '17:05:00', 'PRESENT', 0, 8.16, '2026-10-28 13:48:40');

-- Table: grace_minutes (2 rows)
INSERT INTO `grace_minutes` (`id`, `faculty_id`, `month_year`, `allowed_minutes`, `used_minutes`, `remaining_minutes`, `created_at`) VALUES (1, 2, '2026-10', 45, 15, 30, '2026-10-28 13:48:40');
INSERT INTO `grace_minutes` (`id`, `faculty_id`, `month_year`, `allowed_minutes`, `used_minutes`, `remaining_minutes`, `created_at`) VALUES (2, 3, '2026-10', 45, 0, 45, '2026-10-28 13:48:40');

-- Table: substitute_assignments (1 rows)
INSERT INTO `substitute_assignments` (`id`, `leave_application_id`, `original_faculty_id`, `substitute_faculty_id`, `department_id`, `assignment_date`, `start_time`, `end_time`, `class_details`, `status`, `created_at`) VALUES (1, 101, 2, 3, 1, '2026-10-28', '10:00:00', '11:00:00', 'MCA-II Python Programming Lab', 'ACCEPTED', '2026-10-28 13:48:40');

-- Table: holidays (3 rows)
INSERT INTO `holidays` (`id`, `holiday_date`, `title`, `holiday_type`, `created_at`) VALUES (1, '2026-01-26', 'Republic Day', 'NATIONAL', '2026-10-28 13:48:40');
INSERT INTO `holidays` (`id`, `holiday_date`, `title`, `holiday_type`, `created_at`) VALUES (2, '2026-08-15', 'Independence Day', 'NATIONAL', '2026-10-28 13:48:40');
INSERT INTO `holidays` (`id`, `holiday_date`, `title`, `holiday_type`, `created_at`) VALUES (3, '2026-10-02', 'Gandhi Jayanti', 'NATIONAL', '2026-10-28 13:48:40');

-- Table: audit_logs (2 rows)
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `timestamp`) VALUES (1, 1, 'SYSTEM_INIT', 'SYSTEM', 'SYS001', 'ERP System initialized successfully.', '127.0.0.1', '2026-10-28 13:48:40');
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity_type`, `entity_id`, `details`, `ip_address`, `timestamp`) VALUES (2, 1, 'LOGIN_SUCCESS', 'USER', '1', 'Admin logged in successfully.', '127.0.0.1', '2026-10-28 13:48:40');

SET FOREIGN_KEY_CHECKS = 1;
